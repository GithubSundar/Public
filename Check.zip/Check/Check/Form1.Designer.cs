﻿namespace Check
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            button1 = new Button();
            label1 = new Label();
            dgvSource = new DataGridView();
            dgvDest = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvDest).BeginInit();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(277, 621);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(134, 27);
            textBox1.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(475, 625);
            button1.Name = "button1";
            button1.Size = new Size(97, 33);
            button1.TabIndex = 1;
            button1.Text = "Ok";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(658, 631);
            label1.Name = "label1";
            label1.Size = new Size(17, 20);
            label1.TabIndex = 2;
            label1.Text = "0";
            // 
            // dgvSource
            // 
            dgvSource.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSource.Location = new Point(73, 52);
            dgvSource.Name = "dgvSource";
            dgvSource.RowHeadersWidth = 51;
            dgvSource.Size = new Size(898, 520);
            dgvSource.TabIndex = 3;
            // 
            // dgvDest
            // 
            dgvDest.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDest.Location = new Point(1042, 33);
            dgvDest.Name = "dgvDest";
            dgvDest.RowHeadersWidth = 51;
            dgvDest.Size = new Size(578, 539);
            dgvDest.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1710, 698);
            Controls.Add(dgvDest);
            Controls.Add(dgvSource);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvDest).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Button button1;
        private Label label1;
        private DataGridView dgvSource;
        private DataGridView dgvDest;
    }
}
