using System.Collections.Generic;
using System.Data;
using System.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Check
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            DataTable dtSource = new DataTable();
            dtSource.Columns.Add("Transaction#", typeof(int));
            dtSource.Columns.Add("CustomerId#", typeof(int));
            dtSource.Columns.Add("Date", typeof(DateTime));
            dtSource.Columns.Add("MonthYear", typeof(string));
            dtSource.Columns.Add("Amount", typeof(float));
            dtSource.Columns.Add("Points", typeof(int));


            DataTable dtDestination = new DataTable();
            dtDestination.Columns.Add("CustomerId#", typeof(int));
            dtDestination.Columns.Add("MonthYear", typeof(string));
            dtDestination.Columns.Add("TotalPoints", typeof(int));


            Random rnd = new Random();
            int srcRowCount = rnd.Next(1, 500);


            for (int i = 0; i < srcRowCount; i++)
            {
                DataRow dr = dtSource.NewRow();
                dr["Transaction#"] = i + 1;
                dr["CustomerId#"] = rnd.Next(1, 5);
                dr["Date"] = GetRandomDate();
                dr["MonthYear"] = Convert.ToDateTime(dr["Date"]).ToString("MMM yyyy");
                dr["Amount"] = rnd.Next(1, 999) + Math.Round(Math.Round(new decimal(rnd.NextDouble()), 2), 2);
                dr["Points"] = CalculatePoints(Convert.ToInt32(dr["Amount"]));
                dtSource.Rows.Add(dr);
            }

            dgvSource.DataSource = dtSource;

            

            dtDestination = dtSource.AsEnumerable()
                .GroupBy(r => new
                {
                    CustomerId = r.Field<int>("CustomerId#"),
                    MonthYear = r.Field<DateTime>("Date").ToString("MMM yyyy")
                })
               .OrderBy(r => r.Key.CustomerId).ThenBy(r => r.Key.MonthYear)

             .Select(g =>
            {
                var row = dtDestination.NewRow();
                row["CustomerId#"] = g.Key.CustomerId;
                row["MonthYear"] = g.Key.MonthYear;
                row["TotalPoints"] = g.Sum(r => r.Field<int>("Points"));
                return row;
            }).CopyToDataTable();

            dgvDest.DataSource = dtDestination;
        }

        public DateTime GetRandomDate(int minYear = 2024, int maxYear = 2024)
        {
            Random random = new Random();
            var year = random.Next(minYear, maxYear);
            var month = random.Next(7, 10);
            var noOfDaysInMonth = DateTime.DaysInMonth(year, month);
            var day = random.Next(1, noOfDaysInMonth);

            return new DateTime(year, month, day);
        }

        public int CalculatePoints(int amountSpent)
        {
            int twoPoints = ((amountSpent / 100) > 0) ? (amountSpent - 100) : 0;
            int onePoint = ((amountSpent / 50) > 0) ? (amountSpent - 50 - twoPoints) : 0;
            int totalPoints = (twoPoints * 2) + onePoint;
            return totalPoints;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = CalculatePoints(Convert.ToInt32(textBox1.Text)).ToString();
        }

    }
}
